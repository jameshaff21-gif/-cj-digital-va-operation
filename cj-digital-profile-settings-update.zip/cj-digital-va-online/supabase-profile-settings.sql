-- CJ Digital Marketplace: My Profile settings
-- Run this in Supabase SQL Editor before deploying the updated index.html.
-- Allows each signed-in user to update ONLY their own display name.

create or replace function public.update_my_profile(p_full_name text)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_name text := btrim(coalesce(p_full_name, ''));
  v_user uuid := auth.uid();
begin
  if v_user is null then
    raise exception 'Authentication required';
  end if;
  if length(v_name) < 2 or length(v_name) > 100 then
    raise exception 'Name must be between 2 and 100 characters';
  end if;
  update public.staff_profiles
     set full_name = v_name
   where user_id = v_user and is_active = true;
  if not found then
    raise exception 'Active staff profile not found';
  end if;
end;
$$;

revoke all on function public.update_my_profile(text) from public, anon;
grant execute on function public.update_my_profile(text) to authenticated;
