-- CJ Digital Marketplace: production-hardening migration for the current schema
-- Run in Supabase SQL Editor AFTER the initial schema and security update.
-- This migration makes Buyer clock-in/out happen through authenticated RPCs.

-- Remove direct Buyer writes to attendance; RPCs below perform validated writes.
drop policy if exists "Managers insert attendance" on public.attendance;
drop policy if exists "Managers update attendance" on public.attendance;
create policy "Managers manage attendance"
on public.attendance for all to authenticated
using (public.is_manager()) with check (public.is_manager());

-- Keep manager full access and buyers' own read access. Remove direct buyer insert policy.
drop policy if exists "Staff submit own orders" on public.order_submissions;
create policy "Staff submit own orders"
on public.order_submissions for insert to authenticated
with check (staff_id = auth.uid());

create or replace function public.buyer_clock_in(p_overtime_opt_in boolean default false)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user uuid := auth.uid();
  v_id uuid;
  v_shift_id uuid;
  v_today date := (now() at time zone 'Asia/Manila')::date;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.staff_profiles where user_id=v_user and role='buyer' and is_active=true) then
    raise exception 'Active Buyer profile required';
  end if;
  if exists (select 1 from public.attendance where staff_id=v_user and clock_out is null) then
    raise exception 'You already have an open attendance session';
  end if;
  select id into v_shift_id from public.shifts
    where staff_id=v_user and effective_date <= v_today
    order by effective_date desc, created_at desc limit 1;
  insert into public.attendance(staff_id,work_date,shift_id,clock_in,overtime_opt_in)
  values(v_user,v_today,v_shift_id,now(),coalesce(p_overtime_opt_in,false))
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.buyer_clock_out()
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user uuid := auth.uid();
  v_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  update public.attendance
    set clock_out=now()
    where staff_id=v_user and clock_out is null
    returning id into v_id;
  if v_id is null then raise exception 'No open attendance session found'; end if;
  return v_id;
end;
$$;

revoke all on function public.buyer_clock_in(boolean) from public, anon;
revoke all on function public.buyer_clock_out() from public, anon;
grant execute on function public.buyer_clock_in(boolean) to authenticated;
grant execute on function public.buyer_clock_out() to authenticated;

-- Ensure buyers cannot modify manager-approved overtime values through direct updates.
-- The only attendance update policy is Manager-only; Buyers clock out through RPC.
